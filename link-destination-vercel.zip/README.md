# Link Destination — iPhone → GitHub → Vercel

## Deploy
1. Tạo repository mới trên GitHub.
2. Upload toàn bộ file/thư mục trong project này.
3. Vào Vercel và import repository.
4. Deploy với cấu hình mặc định.
5. Mở domain Vercel được cấp.

## Cấu trúc
- `public/index.html` — giao diện.
- `api/resolve.js` — API lấy URL sau HTTP redirect.
- `vercel.json` — cấu hình route.
- `package.json` — metadata.

Không dùng để vượt CAPTCHA, đăng nhập hoặc cơ chế bảo mật.
