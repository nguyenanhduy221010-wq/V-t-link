export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Chỉ hỗ trợ POST." });
  }

  const raw = String(req.body?.url || "").trim();
  if (!raw) return res.status(400).json({ error: "Vui lòng nhập URL." });

  let url;
  try {
    url = new URL(raw);
  } catch {
    return res.status(400).json({ error: "URL không hợp lệ." });
  }

  if (!["http:", "https:"].includes(url.protocol)) {
    return res.status(400).json({ error: "Chỉ hỗ trợ http/https." });
  }

  try {
    // Follow ordinary HTTP redirects. This does not bypass CAPTCHA/login.
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);

    const response = await fetch(url, {
      method: "HEAD",
      redirect: "follow",
      signal: controller.signal,
      headers: { "User-Agent": "LinkDestinationTool/1.0" }
    });

    clearTimeout(timer);

    return res.status(200).json({
      input: raw,
      destination: response.url,
      status: response.status
    });
  } catch {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(url, {
        method: "GET",
        redirect: "follow",
        signal: controller.signal,
        headers: {
          "User-Agent": "LinkDestinationTool/1.0",
          "Range": "bytes=0-0"
        }
      });

      clearTimeout(timer);

      return res.status(200).json({
        input: raw,
        destination: response.url,
        status: response.status
      });
    } catch {
      return res.status(502).json({
        error: "Không lấy được link đích. Trang có thể chặn truy cập tự động, yêu cầu CAPTCHA/đăng nhập hoặc không hỗ trợ bot."
      });
    }
  }
}
